$function(){
  var docEl=$(document),
    animEl=$('bodySection');
  docEl.on('scroll',funtion(){
    var curScrollPos=docEl.scrollTop();
    animEl.each(function(){
      var $this=this
    });
  });
}
